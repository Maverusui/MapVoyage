#import necessary libraries

import requests
from datetime import datetime
import json
import os

# Retrieve key from the environment variable
user_api = os.environ.get('user_api')
# OpenWeatherMap API key
user_api = user_api

# Function to fetch weather data for a given set of coordinates
def get_weather_data(coordinates):
    complete_api_link = f"https://api.openweathermap.org/data/2.5/weather?lat={coordinates[1]}&lon={coordinates[0]}&appid={user_api}"
    api_link = requests.get(complete_api_link)
    api_data = api_link.json()
    return api_data

# Load the JSON file containing route data
with open('output.json', 'r') as json_file:
    route_data = json.load(json_file)

# Iterate over each route
for route_index, route in enumerate(route_data['routes']):
    print(f"Route {route_index + 1}:")
    
    # Iterate over each set of coordinates in the route's geometry
    for coordinates_index, coordinates in enumerate(route['geometry']['coordinates']):
        latitude, longitude = coordinates
        
        # Fetch weather data for the coordinates
        api_data = get_weather_data((latitude, longitude))
        
        # Extract relevant weather information
        temp_city = ((api_data['main']['temp']) - 273.15)
        weather_desc = api_data['weather'][0]['description']
        hmdt = api_data['main']['humidity']
        wind_spd = api_data['wind']['speed']
        date_time = datetime.now().strftime("%d %b %Y | %I:%M:%S %p")

        # Display weather information for each checkpoint manually
        print("-------------------------------------------------------------")
        print(f"Weather Stats for Checkpoint {coordinates_index + 1} in Route {route_index + 1} || {date_time}")
        print("-------------------------------------------------------------")
        print("Current temperature is: {:.2f} deg C".format(temp_city))
        print("Current weather desc  :", weather_desc)
        print("Current Humidity      :", hmdt, '%')
        print("Current wind speed    :", wind_spd, 'kmph')