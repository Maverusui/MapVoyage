
# to generate a .json file with coordinates of checkpoints and save it
from ads import directions_api_url
import requests
import json

directions_response= requests.get(directions_api_url)
jsondata_directions=directions_response.json()
with open('output.json', 'w') as json_file:
        json.dump(jsondata_directions, json_file, indent=2)


