from ads import directions_api_url
import requests
import json
from apiweather import get_weather_data

directions_response= requests.get(directions_api_url)
jsondata_directions=directions_response.json()
with open('output.json', 'w') as json_file:
        json.dump(jsondata_directions, json_file, indent=2)

# Load the JSON file containing route data
with open('output.json', 'r') as json_file:
    route_data = json.load(json_file)

# Variables for weather data
temperatures = []
humidities = []
weather_conditions = []


# Iterate over each route
for route_index, route in enumerate(route_data['routes']):
    print(f"Route {route_index + 1}:")
    
    # Iterate over each set of coordinates in the route's geometry
    for coordinates_index, coordinates in enumerate(route['geometry']['coordinates']):
        latitude, longitude = coordinates
        
        # Fetch weather data for the coordinates
        api_data = get_weather_data((latitude, longitude))

