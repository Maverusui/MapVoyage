import os
from dotenv import load_dotenv,dotenv_values
load_dotenv()
import requests

# Retrieve key from the environment variable
mapbox_api_key = os.getenv("mapbox_api_key")

# Mapbox Geocoding API endpoint
geocoding_endpoint = f'https://api.mapbox.com/geocoding/v5/mapbox.places/{{place_name}}.json?access_token={mapbox_api_key}'

# Enter places
start_name = input("Enter the 1st place: ")
end_name = input("Enter the 2nd place: ")

# Make the API request
start_response = requests.get(geocoding_endpoint.format(place_name=start_name))
end_response = requests.get(geocoding_endpoint.format(place_name=end_name))

jsondata_start = start_response.json()
jsondata_end = end_response.json()

start_coord = jsondata_start['features'][0]['geometry']['coordinates']
end_coord = jsondata_end['features'][0]['geometry']['coordinates']

start_coord_str = ','.join(map(str, start_coord))
end_coord_str = ','.join(map(str, end_coord))

directions_api_url = f'https://api.mapbox.com/directions/v5/mapbox/cycling/{start_coord_str};{end_coord_str}?geometries=geojson&access_token={mapbox_api_key}'

print(directions_api_url)
