import json
from apiweather import get_weather_data

# Load the JSON file containing route data
with open('output.json', 'r') as json_file:
    route_data = json.load(json_file)

# Variables for weather data
weather_data = []

# Iterate over each route
for route_index, route in enumerate(route_data['routes']):
    # Extract coordinates from the 'geometry' key
    coordinates_list = route['geometry']['coordinates']
    
    # Iterate over each set of coordinates in the route's geometry
    for coordinates_index, coordinates in enumerate(coordinates_list):
        latitude, longitude = coordinates
        
        # Fetch weather data for the coordinates
        api_data = get_weather_data((latitude, longitude))
        
        # Extract relevant weather information
        temperature = api_data['main']['temp']
        humidity = api_data['main']['humidity']
        weather_condition = api_data['weather'][0]['description']
        
        # Add weather data to the list
        weather_data.append({
            "latitude": latitude,
            "longitude": longitude,
            "temperature": temperature,
            "humidity": humidity,
            "weather_condition": weather_condition
        })

# Save weather data to a JSON file
with open('weather_data.json', 'w') as json_file:
    json.dump(weather_data, json_file, indent=2)